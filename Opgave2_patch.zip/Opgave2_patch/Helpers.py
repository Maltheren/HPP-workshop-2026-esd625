
import numpy as np
import matplotlib.pyplot as plt
import networkx as nx
 




def random_dag(n, edge_prob=0.3, seed=None):
    rng = np.random.default_rng(seed)
    adj = np.zeros((n, n), dtype=int)
    
    adj[0,0] = 1
    # Kun kanter fremad (i -> j hvor j > i) = garanteret acyklisk
    for i in range(n):
        for j in range(i + 1, n):
            if rng.random() < edge_prob:
                adj[i, j] = 1
    
    return adj




def plot_graph(adj_matrix, title="Graf", directed=False, weighted=False, ax=None):
    """
    Plotter en graf fra en numpy adjacency matrix.
 
    Args:
        adj_matrix: numpy array (n x n)
        title: titlen på grafen
        directed: True hvis grafen er rettet
        weighted: True hvis kantvægte skal vises
        ax: matplotlib Axes objekt (valgfrit)
    """
    adj = np.array(adj_matrix)
 
    if directed:
        G = nx.DiGraph(adj)
    else:
        G = nx.Graph(adj)
 
    if ax is None:
        fig, ax = plt.subplots(figsize=(6, 5))
 
    pos = nx.spring_layout(G, seed=42)
    
    
    n = len(G.nodes)    
    node_size = max(50, 600 - n * 10)  # skalerer ned med antallet af noder
    font_size = max(5, 10 - n // 10)

    nx.draw_networkx_nodes(G, pos, ax=ax, node_size=node_size, node_color="#4C9BE8")
    nx.draw_networkx_labels(G, pos, ax=ax, font_size=font_size, font_color="white", font_weight="bold")
    nx.draw_networkx_edges(
        G, pos, ax=ax,
        arrows=directed,
        arrowstyle="-|>",
        arrowsize=20,
        edge_color="#333333",
        width=0.4,
    )
 
    if weighted:
        edge_labels = {(u, v): f"{d:.1f}" for u, v, d in G.edges(data="weight") if d and d != 0}
        nx.draw_networkx_edge_labels(G, pos, edge_labels=edge_labels, ax=ax, font_size=8)
 
    ax.set_title(title, fontsize=13, fontweight="bold", pad=12)
    ax.axis("off")
 
