import numpy as np
import numpy.typing as npt
import queue
from Helpers import random_dag, plot_graph
import matplotlib.pyplot as plt
from numba import njit
import time 

###Tar en input matrice som en adj_matrix og spytter et BFS tree ud.
###en række repræsenterer idx nodes pil ud til andre
def perform_BFS(start_node, adj_matrix: npt.NDArray):
    ##We choose to represent the output as an adjacency matrix as well
    output_matrix = np.zeros(adj_matrix.shape)
    nodes_to_discover = queue.Queue()
    nodes_to_discover.put(start_node)
    visited = set([start_node])
    
    
    ##Tjekker lige om han er kvadratisk ellers er der jo nok noget galt :/
    if (np.shape(adj_matrix)[0] != np.shape(adj_matrix)[1]):    
        raise ValueError("adjancy matrix was not square, im not sure what to do then")
    


    while not nodes_to_discover.empty():
        node_idx = nodes_to_discover.get()
        ##Vi slår op i matricen på en række og ser hvad der dukker op for hvert index
        for child_idx in range(adj_matrix.shape[1]):
            if child_idx == node_idx:
                continue ##Det ville være fjollet det her
            
            if (adj_matrix[node_idx, child_idx] != 0): ##OKay en kandidat for at blive tilføjet
                # Checker om vi har opdaget den før
                if child_idx in visited:
                    continue
                visited.add(child_idx)
                ##Hvis vi er nået her så kan vi roligt tilføje den
                output_matrix[node_idx, child_idx] = adj_matrix[node_idx, child_idx]
                nodes_to_discover.put(child_idx)
    
    return output_matrix


def run_test(adj):
    t0 = time.perf_counter()
    output = perform_BFS(0, np.zeros([2,2]))
    t1 = time.perf_counter()
    
    t2 = time.perf_counter()
    output = perform_BFS(0, adj)
    t3 = time.perf_counter()
    
    t_setup = t1 - t0
    t_run = t3 - t2
    return t_setup, t_run


###NOTE det her lort kører jo nok med noget O(n^2) pt faktisk... har ik testet den op imod en O(V+E) ish ting.


if __name__ == "__main__":

    adj = random_dag(5000)

    plt.savefig("start.png", dpi=300)
    _, t_run = run_test(adj)
    print(t_run)

    plt.savefig("Result.png",  dpi=300)
    
    


