import numpy as np
import pandas as pd
import time
import random
from Helpers import random_dag
from tqdm import tqdm
import matplotlib.pyplot as plt
import scienceplots
import requests

TOKEN = "8851677787:AAEHvKBTmpAL9oX-DvISl5WAQ3GQgnS1x9c"
CHAT_ID = "8368875984"

def send_telegram(msg):
    url = f"https://api.telegram.org/bot{TOKEN}/sendMessage"
    requests.post(url, data={"chat_id": CHAT_ID, "text": msg})




#########################
# Malthers kvote for    #
# testbenches var       #
# brugt for 2026,       #
# Følgende er Claudes   #
# fortjeneste           #
#########################



def generate_random_adj_matrix(size: int, density: float = 0.3) -> np.ndarray:
    """Generer en tilfældig adjacency matrix med given tæthed af kanter"""
    matrix = np.random.choice([0, 1], size=(size, size), p=[1-density, density])
    np.fill_diagonal(matrix, 0)  # Ingen self-loops
    return matrix


def run_testbench(
    implementations: dict,
    n: int = 20,
    max_size: int = 100,
    density: float = 0.3
) -> pd.DataFrame:
    sizes = list(range(0, max_size + 1, max(1, max_size // n)))
    total_runs = len(sizes) * n * len(implementations)
    results = []

    with tqdm(total=total_runs, unit="run", colour="green") as pbar, \
         tqdm(bar_format="{desc}", leave=True) as telemetry:

        for size in sizes:
            size_results = {name: [] for name in implementations}

            for trial in range(n):
                adj = generate_random_adj_matrix(max(size, 1), density)

                for impl_name, run_test in implementations.items():
                    try:
                        t_setup, t_run = run_test(adj)
                        size_results[impl_name].append(t_run)
                        results.append({
                            "implementation": impl_name,
                            "size":           size,
                            "trial":          trial,
                            "t_setup":        t_setup,
                            "t_run":          t_run,
                            "t_total":        t_setup + t_run,
                            "error":          None
                        })
                    except Exception as e:
                        print(f"Implementation error {impl_name}")
                        size_results[impl_name].append(None)
                        results.append({
                            "implementation": impl_name,
                            "size":           size,
                            "trial":          trial,
                            "t_setup":        None,
                            "t_run":          None,
                            "t_total":        None,
                            "error":          str(e)
                        })

                    pbar.update(1)

            stats = " | ".join(
                f"{name}: {np.mean([t for t in times if t is not None])*1000:.2f}ms"
                if any(t is not None for t in times)
                else f"{name}: ERR"
                for name, times in size_results.items()
            )
            telemetry.set_description(f"  size={size} | {stats}")

    return pd.DataFrame(results)


def summarize(df: pd.DataFrame) -> pd.DataFrame:
    """Aggreger resultater — gennemsnit og std per implementation og størrelse"""
    return (
        df[df["error"].isna()]  # Filtrer fejlede runs fra
        .groupby(["implementation", "size"])[["t_setup", "t_run", "t_total"]]
        .agg(["mean", "std"])
        .round(6)
    )


def plot_benchmark(df: pd.DataFrame, log_scale: bool = True):
    with plt.style.context(["science", "notebook"]):
        fig, ax = plt.subplots(figsize=(8, 5))

        for impl_name, group in df[df["error"].isna()].groupby("implementation"):
            stats = group.groupby("size")["t_run"].agg(["mean", "std"])
            
            ax.plot(stats.index, stats["mean"], marker="o", label=impl_name)
            ax.fill_between(
                stats.index,
                stats["mean"] - stats["std"],
                stats["mean"] + stats["std"],
                alpha=0.2
            )

        if log_scale:
            ax.set_yscale("log")

        ax.set_xlabel("Number of nodes")
        ax.set_ylabel("Runtime (s) — log scale" if log_scale else "Runtime (s)")
        ax.set_title("BFS Implementation Benchmark")
        ax.legend()
        ax.grid(True, which="both", linestyle="--", alpha=0.5)

        plt.tight_layout()
        plt.savefig("benchmark.png", dpi=300)
        plt.show()

if __name__ == "__main__":

    import Multiprocessing_BFS
    import Sequential_BFS

    implementations = {
        "parallel_bfs": lambda adj: Multiprocessing_BFS.run_test(adj),
        "sequential_bfs": lambda adj: Sequential_BFS.run_test(adj),
    }
    send_telegram("Starting test :)))")
    df = run_testbench(implementations, 100, 5000, 0.3)
    send_telegram("Test done :)))")

    df.to_csv("results.csv")
    plot_benchmark(df)

    summarize(df)