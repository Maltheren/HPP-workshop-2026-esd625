import numpy as np
import numpy.typing as npt
from Helpers import random_dag, plot_graph
import matplotlib.pyplot as plt
from numba import njit
import multiprocessing as mp
from multiprocessing import shared_memory
import time

def worker_explore_node(args):
    node, shm_name, matrix_shape, matrix_dtype, discovered_set = args
    
    ##Her må banditten læse fra
    existing_shm = shared_memory.SharedMemory(name=shm_name)
    
    ##Adjency matricen kommer direkte derfra
    adj_matrix = np.ndarray(matrix_shape, dtype=matrix_dtype, buffer=existing_shm.buf)

    neighbors = []
    
    ##Vi slår op på en række og ser hvem der er forbundet
    for neighbor, connected in enumerate(adj_matrix[node]):
        if connected and neighbor not in discovered_set:
            ##Hvis vi finder noget på det her lag som ikke er opdaett i forvejen så får det lov at blive tilføjet
            neighbors.append((node, neighbor))
    
    existing_shm.close()
    return neighbors



def perform_BFS_parallel(start_node, adj_matrix: npt.NDArray, n_workers: int = mp.cpu_count()):
    if adj_matrix.shape[0] != adj_matrix.shape[1]:
        raise ValueError("Adjacency matrix was not square")

    # Creates a shared memeory bank for our complete graph
    shm = shared_memory.SharedMemory(create=True, size=adj_matrix.nbytes)
    shared_matrix = np.ndarray(adj_matrix.shape, dtype=adj_matrix.dtype, buffer=shm.buf)
    shared_matrix[:] = adj_matrix[:]



    ##THe output graph
    output_matrix = np.zeros(adj_matrix.shape)
    ##Creates a list of discovered stuff
    discovered = set([start_node])
    ##And the current level of stuff all multiprocessors should try to explore
    current_level = [start_node]

    try:
        # Pool spawnes én gang her, ideen er at i stedet for subproc sætter en ny py interpretor op så genbruger vi
        with mp.Pool(processes=n_workers) as pool:
            

            while current_level:
                #Så vi laver en liste af argumenter her som er det der skal opdages, og de få lige de nyeste kendte opdagelser med.
                args = [
                    (node, shm.name, adj_matrix.shape, adj_matrix.dtype, discovered)
                    for node in current_level
                ]


                # Uddeler arbejde til de workers vi jo så har sat op 1 gang
                results = pool.map(worker_explore_node, args) 

                ##Det her er så en fronter, og det kan ske at 2 noder jo bliver opdaget af forskellige kerner
                next_level = []
                for edges in results:
                    ##Her der samler vi dem så, til en liste med næste frontier og fjerner duplicates
                    for (src, dst) in edges:
                        if dst not in discovered:
                            discovered.add(dst)
                            output_matrix[src][dst] = 1
                            next_level.append(dst)
                current_level = next_level

    ##Idk noget memory management der lige lukker den her delte bandit
    finally:
        shm.close()
        shm.unlink()

    return output_matrix
    

def run_test(adj):
    t0 = time.perf_counter()
    output = perform_BFS_parallel(0, np.zeros([2,2]))

    t1 = time.perf_counter()

    t2 = time.perf_counter()
    output = perform_BFS_parallel(0, adj)
    t3 = time.perf_counter()

    t_setup = t1 - t0
    t_run = t3 - t2
    
    return t_setup, t_run




if __name__ == "__main__":

    
    adj = random_dag(5000)
#    plot_graph(adj)

    plt.savefig("start.png", dpi=300)
    _, t_run = run_test(adj)
    print(t_run)
#    plot_graph(output)

    plt.savefig("Result.png",  dpi=300)
    
    


