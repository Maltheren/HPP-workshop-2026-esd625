import numpy as np
import numpy.typing as npt
import queue
from Helpers import random_dag, plot_graph
import matplotlib.pyplot as plt
from numba import njit
from mpi4py import MPI

comm = MPI.COMM_WORLD
rank = comm.Get_rank()   # hvilken proces er jeg?
size = comm.Get_size()   # hvor mange processer i alt?


###Tar en input matrice som en adj_matrix og spytter et BFS tree ud.
###en række repræsenterer idx nodes pil ud til andre
def perform_BFS(start_node, adj_matrix: npt.NDArray):
    ##We choose to represent the output as an adjacency matrix as well
    output_matrix = np.zeros(adj_matrix.shape)
    nodes_to_discover = queue.Queue()
    nodes_to_discover.put(start_node)

    ##Tjekker lige om han er kvadratisk ellers er der jo nok noget galt :/
    if (np.shape(adj_matrix)[0] != np.shape(adj_matrix)[1]):    
        raise ValueError("adjancy matrix was not square, im not sure what to do then")
    





    return output_matrix








if __name__ == "__main__":
    output = perform_BFS(0, np.zeros([2,2]))

    adj = random_dag(5000)
    #plot_graph(adj)

    plt.savefig("start.png", dpi=300)
    
    output = perform_BFS(0, adj)
    #plot_graph(output)

    plt.savefig("Result.png",  dpi=300)
    
    


